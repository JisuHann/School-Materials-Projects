package chatting;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.*;

public class SketchChatClient extends JFrame implements ActionListener,ItemListener
{
	Socket sock;
	OutputStream ostream;InputStream istream;BufferedReader keyRead;
	ObjectOutputStream oos; ObjectInputStream ois;PrintWriter pwrite;Object obj;
	String receiveMessage, sendMessage;BufferedReader receiveRead;
	
	public static void main(String[] args) {
		SketchChatClient screen = new SketchChatClient("CLIENT PAINT");
		screen.setSize(SketchChatClient.WIDTH, SketchChatClient.HEIGHT);
		screen.setVisible(true);
	}
	
	static final int WIDTH = 800;
	static final int HEIGHT = 600;
	int upperLeftX, upperLeftY;
	int width, height;
	int x1, y1, x2, y2;
	boolean fill = false;
	boolean erasure = false;
	String drawColor = new String("black");
	String drawShape = new String("line");
	JTextField color = new JTextField(10);
	JTextField shape = new JTextField(10);
	JTextField position = new JTextField("(0,0)", 10);
	JTextField client = new JTextField(50);
	JButton clientsend = new JButton("SEND TO SERVER");
	ButtonGroup fillOutline = new ButtonGroup();
	JRadioButton fillButton = new JRadioButton("fill");
	JRadioButton outlineButton = new JRadioButton("outline", true);

	String[] colorNames = { "black", "blue", "cyan", "gray", "green", "magenta", "red", "white", "yellow" };
	String[] shapeNames = { "line", "square", "rectangle", "circle", "ellipse" };
	String[] toolNames = { "erase", "clearpad" };
	String[] helpNames = { "information", "about" };
	String helpText = "Sketchpad allows you to draw different plane shapes over a predefined area.\n"
			+ "A shape may be either filled or in outline, and in one of eight different colors.\n\n"
			+ "The position of the mouse on the screen is recorded in the bottom left-hand \n"
			+ "corner of the sketchpad. The choice of color and shape are displayed also in \n"
			+ "the left-hand corner of the sketchpad\n\n"
			+ "The size of a shape is determined by the position of the mouse when the mouse \n"
			+ "button is first pressed, followed by the mouse being dragged to the final position\n"
			+ "and released. The first press of the mouse button will generate a reference dot \n"
			+ "on the screen. This dot will disappear after the mouse button is released\n\n"
			+ "Both the square and circle only use the distance measured along the horizontal \n"
			+ "axis when determining the size of the shape.\n\n"
			+ "Upon selecting erase, press the mouse button, and move the mouse over the area\n"
			+ "to be erased. Releasing the mouse button will deactivate erasure\n\n"
			+ "To erase this text area choose clearpad from the TOOLS menu\n\n";

	TextArea info = new TextArea(helpText, 0, 0, TextArea.SCROLLBARS_VERTICAL_ONLY);
	JFrame about = new JFrame("About Sketchpad");
	JPanel north = new JPanel();
	JPanel south = new JPanel();
	JTabbedPane jtp = new JTabbedPane();
	CenterJPanel canvas = new CenterJPanel();
	JPanel chat = new JPanel();
	JPanel chatsouth = new JPanel();
	JPanel chatcenter = new JPanel();
	JTextArea chattxt = new JTextArea();
	JScrollPane scroll = new JScrollPane(chattxt);
	JColorChooser colorchooser = new JColorChooser();
	Color choosed = Color.black;
	JButton colorbutton = new JButton("Choose color");
		
	class CenterJPanel extends JPanel implements MouseListener,MouseMotionListener
	{
		CenterJPanel() {
			this.addMouseMotionListener(this);
			this.addMouseListener(this);
		}
		
		public void mouseDragged(MouseEvent event)
		{
			Graphics g = getGraphics();
			x2 = event.getX();
			y2 = event.getY();
			if (erasure) {
				g.setColor(Color.yellow);
				g.fillRect(x2, y2, 5, 5);
			}
		}
		public void mouseMoved(MouseEvent event) {
			displayMouseCoordinates(event.getX(), event.getY());
		}
		public void mouseClicked(MouseEvent event) {
		}

		public void mouseEntered(MouseEvent event) {
		}

		public void mouseExited(MouseEvent event) {
		}
		public void mousePressed(MouseEvent event)
		{
			if (erasure)
				return;
			upperLeftX = 0;
			upperLeftY = 0;
			width = 0;
			height = 0;
			x1 = event.getX();
			y1 = event.getY();
			Graphics g = getGraphics();
			g.drawString(".", x1, y1);
			displayMouseCoordinates(event.getX(), event.getY());
		}

		public void mouseReleased(MouseEvent event)
		{
			Graphics g = getGraphics();
			displayMouseCoordinates(event.getX(), event.getY());
			if (erasure) {
				erasure = false;
				return;
			}
			selectColor(g);
			x2 = event.getX();
			y2 = event.getY();

			if (drawShape.equals("line")) {
				g.drawLine(x1, y1, x2, y2);
			} else if (drawShape.equals("circle")) {
				closedShapes(g, "circle", fill);
			} else if (drawShape.equals("ellipse")) {
				closedShapes(g, "ellipse", fill);
			} else if (drawShape.equals("square")) {
				closedShapes(g, "square", fill);
			} else if (drawShape.equals("rectangle")) {
				closedShapes(g, "rectangle", fill);
			}
			g.setColor(Color.yellow);
			g.drawString(".", x1, y1);
			g.setColor(Color.black);
		}

	}
	
	private void initializeJTextFields() {
		color.setBackground(Color.white);
		color.setText(drawColor);
		north.add(color);

		shape.setBackground(Color.white);
		shape.setText(drawShape);
		north.add(shape);

		position.setBackground(Color.white);
		north.add(position);
		
		info.setBackground(Color.white);
		info.setEditable(false);
		
		north.add(colorbutton);
		colorbutton.setActionCommand("colorIcon");
		colorbutton.addActionListener(this);
		colorbutton.setBackground(Color.red);
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		Graphics g=getGraphics();
		Object source = arg0.getActionCommand();
		System.out.println("Action Performed");
		System.out.println(source.toString());
		
		//send client message to Server
		if(source.equals("send")) {
			try {
				System.out.println("\nSEND CLIENT MESSAGE");
				sendMessage = client.getText();	//get client text
				client.setText("");	//reset client text
				if(sendMessage != null) {	//send only not null message
					pwrite.println(sendMessage);
					pwrite.flush();
					String clientmsg =("ME: "+sendMessage+"\n");	//add client message at jtextarea
					sendMessage = "";
					chattxt.append(clientmsg);
					chatcenter.validate();							//update jtextarea
					chattxt.setCaretPosition(chattxt.getText().length());	//make jtextarea scrollable
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		//set color
		for(int i = 0;i!=colorNames.length;i++) {
			if(source.equals(colorNames[i])) {
				drawColor = colorNames[i];
				color.setText(drawColor);
				return;
			}
		}
		
		//set shape
		for(int k=0;k!=shapeNames.length;k++) {
			if(source.equals(shapeNames[k])) {
				drawShape = shapeNames[k];
				shape.setText(drawShape);
				return;
			}
		}
		
		//set colorchooser
		if(source.equals("colorIcon")) {
			Color selected = colorchooser.showDialog(null, "color", Color.yellow);
			choosed=selected;
			drawColor = selected.toString();
			color.setText(drawColor);
		}
		
		if(source.equals("erase")) {
			erasure = true;
			return;
		}
		
		//clear pad
		if(source.equals("clearpad")) {
			remove(info);
			g.clearRect(0, 0, 800, 600);
			return;
		}
		
		if(source.equals("information")) {
			add(info);return;
		}else if(source.equals("about")) {
			displayAboutWindow(about);
		}
	}
	
	private void initializeMenuComponents() {
		MenuBar bar = new MenuBar();

		Menu shapes = new Menu("SHAPES");
		for (int index = 0; index != shapeNames.length; index++)
			shapes.add(shapeNames[index]);
		bar.add(shapes);
		shapes.addActionListener(this);

		// add tools menu
		Menu tools = new Menu("TOOLS");
		for (int index = 0; index != toolNames.length; index++)
			tools.add(toolNames[index]);
		bar.add(tools);
		tools.addActionListener(this);

		// add help menu
		Menu help = new Menu("HELP");
		for (int index = 0; index != helpNames.length; index++)
			help.add(helpNames[index]);
		bar.add(help);
		help.addActionListener(this);

		setMenuBar(bar);
	}

	//set radio button
	private void initializeRadioButtons() {
		south.add(fillButton);
		fillButton.addItemListener(this);

		south.add(outlineButton);
		outlineButton.addItemListener(this);
	}

	// constructor
	public SketchChatClient(String s) {
		super(s);
		setBackground(Color.yellow);setVisible(true);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		this.setSize(new Dimension(screenSize.height,screenSize.width/2));
		this.add(north, BorderLayout.NORTH);
		this.add(south, BorderLayout.SOUTH);
		
		//set jtabbedpane - tab1: canvas / tab2: chat(chattxt)
		jtp.addTab("SKETCH", null,canvas);jtp.addTab("CHAT", null, chat);
		chat.setLayout(new BorderLayout());
		chat.add(chatcenter,BorderLayout.CENTER);chat.add(chatsouth, BorderLayout.SOUTH);
		chatsouth.add(client);Font font = new Font("Verdana", Font.BOLD, 15);chattxt.setFont(font);
		chatcenter.setLayout(new BorderLayout());chatcenter.add(chattxt,BorderLayout.CENTER);
		chattxt.setEditable(false);chattxt.setOpaque(true);
		chatsouth.add(clientsend);clientsend.addActionListener(this);
		clientsend.setActionCommand("send");
		this.add(jtp, BorderLayout.CENTER);
		
		north.setBackground(Color.gray);
		south.setBackground(Color.white);

		initializeJTextFields();
		initializeMenuComponents();
		initializeRadioButtons();
		
		//connect with server
		try {
			connected();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent event)
			{
				if (event.getWindow() == about) {
					about.dispose();
					return;
				} else {
					System.exit(0);
				}
			}
		});
	}
	
	//Connect with Server
	void connected(){
		System.out.println("This is client. Starting CHAT PROGRAM");
		try {
				//connect and settings
				keyRead = new BufferedReader(new InputStreamReader(System.in));
				Socket sock = new Socket("127.0.0.1",9807);
				ostream = sock.getOutputStream();
				istream = sock.getInputStream();
				pwrite = new PrintWriter(ostream, true);
				receiveRead = new BufferedReader(new InputStreamReader(istream));
				
				//Update message from Server
				while((receiveMessage = receiveRead.readLine())!=null) {
					System.out.println(receiveMessage);
					String servermsg = new String("Server: "+receiveMessage+"\n");
					receiveMessage = "";
					chattxt.append(servermsg);	//append message in Chattxt
					chatcenter.validate();		//update Jtextarea
					chattxt.setCaretPosition(chattxt.getText().length());	//make jtextarea scrollable
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
	}

	
	//set radiobutton: fill or outline
	public void itemStateChanged(ItemEvent event)
	{
		if (fillButton.isSelected())
			fill = true;
		else if (outlineButton.isSelected())
			fill = false;
	}

	protected void displayAboutWindow(JFrame about)
	{
		about.setLocation(300, 300);
		about.setSize(200, 150);
		about.setBackground(Color.cyan);
		about.setFont(new Font("Serif", Font.ITALIC, 14));
		about.setLayout(new FlowLayout(FlowLayout.LEFT));

		about.add(new Label("Author: Barry Holmes"));
		about.add(new Label("Title: Sketchpad"));
		about.add(new Label("Date: 1998"));
		about.add(new Label("Use: Demonstration only"));
		about.setVisible(true);
		about.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}

	//set color choosed
	protected void selectColor(Graphics g)
	{g.setColor(choosed);
	}

	protected void closedShapes(Graphics g, String shape, boolean fill)
	{
		upperLeftX = Math.min(x1, x2);
		upperLeftY = Math.min(y1, y2);
		width = Math.abs(x1 - x2);
		height = Math.abs(y1 - y2);

		if (shape.equals("square") && fill)
			g.fillRect(upperLeftX, upperLeftY, width, width);
		else if (shape.equals("square") && !fill)
			g.drawRect(upperLeftX, upperLeftY, width, width);

		else if (shape.equals("rectangle") && fill)
			g.fillRect(upperLeftX, upperLeftY, width, height);
		else if (shape.equals("rectangle") && !fill)
			g.drawRect(upperLeftX, upperLeftY, width, height);

		else if (shape.equals("circle") && fill)
			g.fillOval(upperLeftX, upperLeftY, width, width);
		else if (shape.equals("circle") && !fill)
			g.drawOval(upperLeftX, upperLeftY, width, width);

		else if (shape.equals("ellipse") && fill)
			g.fillOval(upperLeftX, upperLeftY, width, height);
		else if (shape.equals("ellipse") && !fill)
			g.drawOval(upperLeftX, upperLeftY, width, height);
	}
	
	protected void displayMouseCoordinates(int X, int Y)
	{
		position.setText("[" + String.valueOf(X) + "," + String.valueOf(Y) + "]");
	}
}

