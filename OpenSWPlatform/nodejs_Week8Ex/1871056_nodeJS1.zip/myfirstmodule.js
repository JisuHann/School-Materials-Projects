var myfirstmodule = {
    Date: function(){
        const date = new Date();
        return date.toString();
    }
}
module.exports = myfirstmodule;